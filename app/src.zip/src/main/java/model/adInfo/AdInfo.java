package model.adInfo;

public class AdInfo {

}

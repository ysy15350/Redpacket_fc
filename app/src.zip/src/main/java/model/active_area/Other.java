package model.active_area;

public class Other {
}

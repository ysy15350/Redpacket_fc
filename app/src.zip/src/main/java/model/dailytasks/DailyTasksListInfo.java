package model.dailytasks;

/**
 * 每日任务列表实体
 */
public class DailyTasksListInfo {

}

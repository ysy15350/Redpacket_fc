package model.protocol;

public class ProtoclInfo {

        /**
         * 用户协议
         */
        private String protocol;

        public String getProtocol() {
            return protocol;
        }

        public void setProtocol(String protocol) {
            this.protocol = protocol;
        }
}

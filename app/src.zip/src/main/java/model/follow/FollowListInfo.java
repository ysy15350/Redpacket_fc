package model.follow;

/**
 * 关注列表实体
 */
public class FollowListInfo {

}

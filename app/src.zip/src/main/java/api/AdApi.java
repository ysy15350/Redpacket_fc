package api;

import com.ysy15350.ysyutils.api.ApiCallBack;

/**
 * 广告相关接口
 */
public interface AdApi {

    /**
     * 广告列表
     */
    void getAdInfoList(ApiCallBack callBack);

}

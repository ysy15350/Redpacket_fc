package com.ysy15350.redpacket_fc.active_area.activearea;

import android.content.Context;

import com.ysy15350.ysyutils.base.mvp.BasePresenter;


public class ActiveAreaPresenter extends BasePresenter<ActiveAreaViewInterface> {

    public ActiveAreaPresenter(Context context) {
        super(context);

    }

    public void getAdsCardList(int page,int pageSize){
//        mView.bindAdsCardListCallback(false,null);
    }
    

}

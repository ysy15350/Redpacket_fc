package com.ysy15350.redpacket_fc.active_area.activearea;

/**
 * Created by yangshiyou on 2017/10/30.
 */

public interface ActiveAreaViewInterface {

//    public void bindAdsCardListCallback(boolean isCache, Response response);

}

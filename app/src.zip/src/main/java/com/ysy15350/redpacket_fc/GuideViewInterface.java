package com.ysy15350.redpacket_fc;

import com.ysy15350.ysyutils.api.model.Response;

/**
 * Created by yangshiyou on 2017/10/30.
 */

public interface GuideViewInterface {

    public void activateCallback(boolean isCache, Response response);

}

package com.ysy15350.redpacket_fc.main_tabs;

import android.content.Context;

import com.ysy15350.ysyutils.base.mvp.BasePresenter;


public class MainTab2Presenter extends BasePresenter<MainTab2ViewInterface> {

    public MainTab2Presenter() {
    }

    public MainTab2Presenter(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
    }


}

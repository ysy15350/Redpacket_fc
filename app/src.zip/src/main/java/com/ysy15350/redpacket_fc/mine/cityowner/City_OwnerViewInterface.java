package com.ysy15350.redpacket_fc.mine.cityowner;

/**
 * Created by yangshiyou on 2017/10/30.
 */

public interface City_OwnerViewInterface {

//    public void bindAdsCardListCallback(boolean isCache, Response response);

}

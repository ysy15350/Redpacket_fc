package com.ysy15350.redpacket_fc.main_tabs;

public interface MainTab2ViewInterface {



}

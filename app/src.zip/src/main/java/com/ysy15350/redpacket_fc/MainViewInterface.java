package com.ysy15350.redpacket_fc;

import com.ysy15350.ysyutils.api.model.Response;

public interface MainViewInterface {

    public void activateCallback(boolean isCache, Response response);


}

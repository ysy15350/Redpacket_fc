package alipay.model;

/**
 * Created by yangshiyou on 2017/9/29.
 */

public class Result {

//    {
//        "memo": "",
//            "result": "
// {\"alipay_trade_app_pay_response\":
// {\"code\":\"10000\",\"msg\":\"Success\"
// ,\"app_id\":\"2017061407489558\",\"auth_app_id\":\"2017061407489558\"
// ,\"charset\":\"utf-8\",\"timestamp\":\"2017-09-29 18:37:58\",
// \"total_amount\":\"0.01\",
// \"trade_no\":\"2017092921001004830274775230\",\"seller_id\":\"2088421590687653\",\"out_trade_no\":\"20170929529235\"},
// \"sign\":\"OajC4A/yLiToekibGNotqAQxDba7ViRRm8A/rS4bHCpfzzFJT8KCS/SRdMpCNqOIMHv7SjKus8VFE9avTr51eGauRTOfG/usYN1KVUS6+ySl+U0F9J6AdLn8UbY9sJ0gSRDielGOsS7y+2lwcmatdwrXPRAONtX0j1XAOfkKYsbbrQAOOXxEbvxVV0wuEPis/XJau4BfJ+WFNJ4Y05TODtdBmZ2xePpIreXKhZeVgTs5X5FBSPLx3YyQ8M553Go3Hk6tt7R/WXi0tSjKXK7d7ksTWXhOrkzMFkaQj8oFzPIZnUgjAMXqjGdgoWLxeHytQGBFdCM9U7djQOXJO5mRww\u003d\u003d\",\"sign_type\":\"RSA2\"}",
//            "resultStatus": "9000"
//    }

    private String sign;
    private String out_trade_no;


}
